// FitForge: SweatSquad Showdown — Client-Side Engine & State

const STORAGE_KEY = "fitforge_sweatsquad_v1";
const MAX_DAILY_MINUTES = 180;
const BOSS_MAX_HP = 3000;

const MET_FACTORS = {
  Running: 9.8,
  Cycling: 8.0,
  Gym: 6.0,
  "Push-ups": 7.5,
};

const INTENSITY_MULTIPLIERS = {
  Low: 0.85,
  Moderate: 1.0,
  High: 1.25,
};

const BADGE_CATALOG = [
  { id: "first_spark", name: "First Spark", icon: "⚡", desc: "Log at least 1 workout session", check: (u) => u.workoutsCount >= 1 },
  { id: "5k_trailblazer", name: "5k Trailblazer", icon: "🏃", desc: "Complete a 5 km+ run or log 300+ pts in one session", check: (u) => u.maxRunKm >= 5 || u.maxSinglePoints >= 300 },
  { id: "10k_runner", name: "10k Runner", icon: "🏅", desc: "Accumulate 10+ km total running distance", check: (u) => u.totalRunKm >= 10 },
  { id: "iron_pumper", name: "Iron Pumper", icon: "🏋️", desc: "Log 3+ Gym or Push-ups workouts", check: (u) => u.strengthCount >= 3 },
  { id: "7_day_streak", name: "7-Day Streak", icon: "🔥", desc: "Maintain a 7-day active workout streak", check: (u) => u.streakDays >= 7 },
  { id: "consistency_beast", name: "Consistency Beast", icon: "🦾", desc: "Earn 650+ personal challenge points", check: (u) => u.points >= 650 },
  { id: "squad_carry", name: "Squad Carry", icon: "🛡️", desc: "Log 5+ total workouts in the challenge", check: (u) => u.workoutsCount >= 5 },
  { id: "centurion", name: "Point Centurion", icon: "👑", desc: "Reach 1,000+ personal challenge points", check: (u) => u.points >= 1000 },
];

function createInitialState() {
  return {
    activeSquadId: "sq-iron",
    activeUserId: "u-alex",
    leaderboardCycle: "weekly",
    chartType: "bar",
    squads: [
      {
        id: "sq-iron",
        name: "Iron Legion",
        inviteCode: "IRON-2026",
        motto: "Forged in grit. Built for weekly dominance.",
        weeklyGoal: 2500,
        weeklyPoints: 1850,
        dailyPoints: 340,
        monthlyPoints: 6420,
        dailyTrend: [210, 260, 290, 240, 310, 200, 340],
      },
      {
        id: "sq-apex",
        name: "Apex Pace",
        inviteCode: "APEX-2026",
        motto: "Negative splits and zero excuses.",
        weeklyGoal: 2500,
        weeklyPoints: 2010,
        dailyPoints: 390,
        monthlyPoints: 7100,
        dailyTrend: [280, 300, 270, 350, 320, 200, 390],
      },
      {
        id: "sq-pulse",
        name: "Pulse Syndicate",
        inviteCode: "PULSE-99",
        motto: "Endurance in every stride.",
        weeklyGoal: 2200,
        weeklyPoints: 1620,
        dailyPoints: 250,
        monthlyPoints: 5890,
        dailyTrend: [190, 220, 250, 240, 270, 200, 250],
      },
      {
        id: "sq-titan",
        name: "Titan Collective",
        inviteCode: "TITAN-04",
        motto: "Heavy sets, higher spirits.",
        weeklyGoal: 2400,
        weeklyPoints: 1490,
        dailyPoints: 210,
        monthlyPoints: 5340,
        dailyTrend: [180, 200, 210, 230, 220, 240, 210],
      },
      {
        id: "sq-vanguard",
        name: "Vanguard Striders",
        inviteCode: "VANG-07",
        motto: "Consistency beats intensity every single week.",
        weeklyGoal: 2000,
        weeklyPoints: 1280,
        dailyPoints: 180,
        monthlyPoints: 4650,
        dailyTrend: [150, 170, 180, 190, 210, 200, 180],
      },
    ],
    users: [
      // Iron Legion (4 members)
      { id: "u-alex", squadId: "sq-iron", name: "Alex Rivera", points: 520, dailyPoints: 90, monthlyPoints: 1840, streakDays: 7, workoutsCount: 4, strengthCount: 1, totalRunKm: 8.5, maxRunKm: 4.5, maxSinglePoints: 245, dailyMinutesLogged: 35, unlockedBadges: ["first_spark", "7_day_streak"], personalTrend: [60, 75, 80, 65, 95, 55, 90] },
      { id: "u-maya", squadId: "sq-iron", name: "Maya Lin", points: 480, dailyPoints: 110, monthlyPoints: 1690, streakDays: 6, workoutsCount: 4, strengthCount: 2, totalRunKm: 5.0, maxRunKm: 5.0, maxSinglePoints: 260, dailyMinutesLogged: 40, unlockedBadges: ["first_spark", "5k_trailblazer"], personalTrend: [55, 70, 65, 60, 80, 60, 80] },
      { id: "u-devon", squadId: "sq-iron", name: "Devon Brooks", points: 440, dailyPoints: 80, monthlyPoints: 1520, streakDays: 5, workoutsCount: 3, strengthCount: 2, totalRunKm: 3.0, maxRunKm: 3.0, maxSinglePoints: 210, dailyMinutesLogged: 30, unlockedBadges: ["first_spark"], personalTrend: [50, 60, 75, 55, 70, 50, 80] },
      { id: "u-priya", squadId: "sq-iron", name: "Priya Nair", points: 410, dailyPoints: 60, monthlyPoints: 1370, streakDays: 8, workoutsCount: 4, strengthCount: 1, totalRunKm: 6.2, maxRunKm: 3.2, maxSinglePoints: 195, dailyMinutesLogged: 25, unlockedBadges: ["first_spark", "7_day_streak"], personalTrend: [45, 55, 70, 60, 65, 35, 90] },

      // Apex Pace (4 members)
      { id: "u-liam", squadId: "sq-apex", name: "Liam Vance", points: 610, dailyPoints: 120, monthlyPoints: 2100, streakDays: 9, workoutsCount: 5, strengthCount: 1, totalRunKm: 12.0, maxRunKm: 7.0, maxSinglePoints: 310, dailyMinutesLogged: 45, unlockedBadges: ["first_spark", "5k_trailblazer", "10k_runner", "7_day_streak", "squad_carry"], personalTrend: [80, 90, 75, 100, 85, 60, 120] },
      { id: "u-zoe", squadId: "sq-apex", name: "Zoe Chen", points: 510, dailyPoints: 95, monthlyPoints: 1820, streakDays: 6, workoutsCount: 4, strengthCount: 1, totalRunKm: 7.5, maxRunKm: 5.0, maxSinglePoints: 240, dailyMinutesLogged: 30, unlockedBadges: ["first_spark", "5k_trailblazer"], personalTrend: [70, 80, 65, 90, 75, 35, 95] },
      { id: "u-omar", squadId: "sq-apex", name: "Omar Farooq", points: 470, dailyPoints: 90, monthlyPoints: 1640, streakDays: 5, workoutsCount: 3, strengthCount: 2, totalRunKm: 4.0, maxRunKm: 4.0, maxSinglePoints: 220, dailyMinutesLogged: 35, unlockedBadges: ["first_spark"], personalTrend: [65, 70, 70, 80, 65, 30, 90] },
      { id: "u-hannah", squadId: "sq-apex", name: "Hannah Kim", points: 420, dailyPoints: 85, monthlyPoints: 1540, streakDays: 7, workoutsCount: 4, strengthCount: 1, totalRunKm: 5.5, maxRunKm: 3.5, maxSinglePoints: 200, dailyMinutesLogged: 25, unlockedBadges: ["first_spark", "7_day_streak"], personalTrend: [65, 60, 60, 80, 95, 40, 85] },

      // Pulse Syndicate (4 members)
      { id: "u-noah", squadId: "sq-pulse", name: "Noah Patel", points: 460, dailyPoints: 70, monthlyPoints: 1620, streakDays: 4, workoutsCount: 3, strengthCount: 1, totalRunKm: 6.0, maxRunKm: 3.5, maxSinglePoints: 215, dailyMinutesLogged: 25, unlockedBadges: ["first_spark"], personalTrend: [60, 70, 80, 70, 60, 50, 70] },
      { id: "u-chloe", squadId: "sq-pulse", name: "Chloe Dubois", points: 430, dailyPoints: 65, monthlyPoints: 1510, streakDays: 6, workoutsCount: 4, strengthCount: 2, totalRunKm: 4.5, maxRunKm: 2.5, maxSinglePoints: 190, dailyMinutesLogged: 20, unlockedBadges: ["first_spark"], personalTrend: [50, 60, 65, 65, 75, 50, 65] },
      { id: "u-tariq", squadId: "sq-pulse", name: "Tariq Al-Mansoor", points: 390, dailyPoints: 60, monthlyPoints: 1420, streakDays: 3, workoutsCount: 3, strengthCount: 1, totalRunKm: 5.0, maxRunKm: 3.0, maxSinglePoints: 185, dailyMinutesLogged: 20, unlockedBadges: ["first_spark"], personalTrend: [45, 50, 55, 55, 70, 50, 60] },
      { id: "u-emma", squadId: "sq-pulse", name: "Emma Walsh", points: 340, dailyPoints: 55, monthlyPoints: 1340, streakDays: 5, workoutsCount: 2, strengthCount: 1, totalRunKm: 3.0, maxRunKm: 3.0, maxSinglePoints: 175, dailyMinutesLogged: 20, unlockedBadges: ["first_spark"], personalTrend: [35, 40, 50, 50, 65, 50, 55] },

      // Titan Collective (4 members)
      { id: "u-marcus", squadId: "sq-titan", name: "Marcus Reid", points: 420, dailyPoints: 65, monthlyPoints: 1480, streakDays: 4, workoutsCount: 4, strengthCount: 3, totalRunKm: 2.0, maxRunKm: 2.0, maxSinglePoints: 195, dailyMinutesLogged: 30, unlockedBadges: ["first_spark", "iron_pumper"], personalTrend: [50, 60, 60, 65, 60, 60, 65] },
      { id: "u-sofia", squadId: "sq-titan", name: "Sofia Alvarez", points: 380, dailyPoints: 55, monthlyPoints: 1350, streakDays: 5, workoutsCount: 3, strengthCount: 2, totalRunKm: 3.5, maxRunKm: 3.5, maxSinglePoints: 180, dailyMinutesLogged: 25, unlockedBadges: ["first_spark"], personalTrend: [45, 50, 55, 55, 60, 60, 55] },
      { id: "u-caleb", squadId: "sq-titan", name: "Caleb Novak", points: 360, dailyPoints: 45, monthlyPoints: 1290, streakDays: 3, workoutsCount: 3, strengthCount: 2, totalRunKm: 1.5, maxRunKm: 1.5, maxSinglePoints: 170, dailyMinutesLogged: 20, unlockedBadges: ["first_spark"], personalTrend: [45, 50, 50, 55, 55, 60, 45] },
      { id: "u-aria", squadId: "sq-titan", name: "Aria Sato", points: 330, dailyPoints: 45, monthlyPoints: 1220, streakDays: 4, workoutsCount: 2, strengthCount: 2, totalRunKm: 2.5, maxRunKm: 2.5, maxSinglePoints: 165, dailyMinutesLogged: 20, unlockedBadges: ["first_spark"], personalTrend: [40, 40, 45, 55, 45, 60, 45] },

      // Vanguard Striders (4 members)
      { id: "u-ethan", squadId: "sq-vanguard", name: "Ethan Grant", points: 350, dailyPoints: 50, monthlyPoints: 1260, streakDays: 4, workoutsCount: 3, strengthCount: 1, totalRunKm: 6.5, maxRunKm: 4.0, maxSinglePoints: 175, dailyMinutesLogged: 20, unlockedBadges: ["first_spark"], personalTrend: [40, 45, 50, 55, 60, 50, 50] },
      { id: "u-nina", squadId: "sq-vanguard", name: "Nina Kowalski", points: 330, dailyPoints: 45, monthlyPoints: 1190, streakDays: 5, workoutsCount: 3, strengthCount: 1, totalRunKm: 5.0, maxRunKm: 3.0, maxSinglePoints: 160, dailyMinutesLogged: 20, unlockedBadges: ["first_spark"], personalTrend: [40, 45, 45, 50, 55, 50, 45] },
      { id: "u-dante", squadId: "sq-vanguard", name: "Dante Morales", points: 310, dailyPoints: 45, monthlyPoints: 1130, streakDays: 3, workoutsCount: 2, strengthCount: 1, totalRunKm: 4.0, maxRunKm: 4.0, maxSinglePoints: 165, dailyMinutesLogged: 20, unlockedBadges: ["first_spark"], personalTrend: [35, 40, 45, 45, 50, 55, 45] },
      { id: "u-leila", squadId: "sq-vanguard", name: "Leila Haddad", points: 290, dailyPoints: 40, monthlyPoints: 1070, streakDays: 4, workoutsCount: 2, strengthCount: 0, totalRunKm: 5.5, maxRunKm: 3.0, maxSinglePoints: 155, dailyMinutesLogged: 15, unlockedBadges: ["first_spark"], personalTrend: [35, 40, 40, 40, 45, 50, 40] },
    ],
    workouts: [
      { id: "w-1", squadId: "sq-iron", userId: "u-maya", userName: "Maya Lin", exercise: "Running", duration: 30, distance: 5.0, intensity: "High", points: 260, note: "Campus track tempo intervals", timestamp: "Today, 07:30 AM" },
      { id: "w-2", squadId: "sq-iron", userId: "u-alex", userName: "Alex Rivera", exercise: "Cycling", duration: 35, distance: 12.0, intensity: "Moderate", points: 245, note: "Lakefront spin before lecture", timestamp: "Yesterday" },
      { id: "w-3", squadId: "sq-apex", userId: "u-liam", userName: "Liam Vance", exercise: "Running", duration: 35, distance: 7.0, intensity: "High", points: 310, note: "Morning threshold run", timestamp: "Today, 06:45 AM" },
      { id: "w-4", squadId: "sq-iron", userId: "u-devon", userName: "Devon Brooks", exercise: "Gym", duration: 40, distance: 0, intensity: "Moderate", points: 210, note: "Upper body compound circuit", timestamp: "Yesterday" },
    ],
    feed: [
      { id: "f-1", squadId: "sq-iron", text: "Maya Lin crushed a 5.0 km High-Intensity Run (+260 pts) and unlocked 5k Trailblazer!", time: "18m ago", highFives: 4 },
      { id: "f-2", squadId: "sq-iron", text: "Priya Nair hit an 8-day workout streak! Consistency is paying off.", time: "2h ago", highFives: 6 },
      { id: "f-3", squadId: "sq-apex", text: "Liam Vance dealt 310 Boss damage with a 7 km tempo run.", time: "1h ago", highFives: 5 },
    ],
  };
}

let state = loadState();
let chartInstance = null;

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn("Storage read fallback:", e);
  }
  return createInitialState();
}

function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.warn("Storage write fallback:", e);
  }
}

function calculateMetPoints(exercise, durationMins, intensity) {
  const met = MET_FACTORS[exercise] ?? 6.0;
  const mult = INTENSITY_MULTIPLIERS[intensity] ?? 1.0;
  return Math.round(durationMins * met * mult);
}

function getSquadPointsByCycle(squad, cycle) {
  if (cycle === "daily") return squad.dailyPoints;
  if (cycle === "monthly") return squad.monthlyPoints;
  return squad.weeklyPoints;
}

function getUserPointsByCycle(user, cycle) {
  if (cycle === "daily") return user.dailyPoints;
  if (cycle === "monthly") return user.monthlyPoints;
  return user.points;
}

function showToast(message) {
  const container = document.getElementById("toast-container");
  const el = document.createElement("div");
  el.className = "toast";
  el.textContent = message;
  container.appendChild(el);
  setTimeout(() => {
    el.style.opacity = "0";
    el.style.transition = "opacity 0.25s ease";
    setTimeout(() => el.remove(), 260);
  }, 3200);
}

function evaluateBadges(user) {
  const newlyUnlocked = [];
  for (const badge of BADGE_CATALOG) {
    if (!user.unlockedBadges.includes(badge.id) && badge.check(user)) {
      user.unlockedBadges.push(badge.id);
      newlyUnlocked.push(badge);
    }
  }
  return newlyUnlocked;
}

function getActiveSquad() {
  return state.squads.find((s) => s.id === state.activeSquadId) || state.squads[0];
}

function getActiveUser() {
  const squad = getActiveSquad();
  const inSquad = state.users.filter((u) => u.squadId === squad.id);
  const current = state.users.find((u) => u.id === state.activeUserId);
  if (current && current.squadId === squad.id) return current;
  state.activeUserId = inSquad[0]?.id || state.users[0].id;
  return state.users.find((u) => u.id === state.activeUserId);
}

function renderAll() {
  const squad = getActiveSquad();
  const user = getActiveUser();

  renderSwitchers(squad, user);
  renderHeroAndBoss(squad, user);
  renderKPIs(squad, user);
  renderLeaderboards(squad);
  renderChart(squad, user);
  renderBadges(user);
  renderFeed(squad);
  renderWorkoutsTable(squad);
  updateMetPreview();
}

function renderSwitchers(activeSquad, activeUser) {
  const squadSelect = document.getElementById("squad-switcher");
  squadSelect.innerHTML = state.squads
    .map((s) => `<option value="${s.id}" ${s.id === activeSquad.id ? "selected" : ""}>${s.name}</option>`)
    .join("");

  const squadMembers = state.users.filter((u) => u.squadId === activeSquad.id);
  const userSelect = document.getElementById("user-switcher");
  userSelect.innerHTML = squadMembers
    .map((u) => `<option value="${u.id}" ${u.id === activeUser.id ? "selected" : ""}>${u.name}</option>`)
    .join("");
}

function renderHeroAndBoss(squad, user) {
  const rankedSquads = [...state.squads].sort(
    (a, b) => getSquadPointsByCycle(b, state.leaderboardCycle) - getSquadPointsByCycle(a, state.leaderboardCycle)
  );
  const rank = rankedSquads.findIndex((s) => s.id === squad.id) + 1;

  document.getElementById("squad-rank-pill").textContent = `#${rank} SQUAD`;
  document.getElementById("squad-invite-pill").textContent = `CODE: ${squad.inviteCode}`;
  document.getElementById("daily-cap-pill").textContent = `Daily Cap: ${user.dailyMinutesLogged} / ${MAX_DAILY_MINUTES} mins`;
  document.getElementById("squad-name").textContent = squad.name;
  document.getElementById("squad-motto").textContent = squad.motto;

  const pct = Math.min(100, Math.round((squad.weeklyPoints / squad.weeklyGoal) * 100));
  document.getElementById("squad-goal-text").textContent = `${squad.weeklyPoints.toLocaleString()} / ${squad.weeklyGoal.toLocaleString()} pts`;
  document.getElementById("squad-goal-bar").style.width = `${pct}%`;

  const remainingHp = Math.max(0, BOSS_MAX_HP - squad.weeklyPoints);
  const hpPct = Math.max(0, Math.min(100, (remainingHp / BOSS_MAX_HP) * 100));
  document.getElementById("boss-hp-text").textContent = `${remainingHp.toLocaleString()} / ${BOSS_MAX_HP.toLocaleString()} HP`;
  document.getElementById("boss-hp-bar").style.width = `${hpPct}%`;
  document.getElementById("boss-status").textContent = remainingHp === 0 ? "DEFEATED!" : "ACTIVE";
}

function renderKPIs(squad, user) {
  document.getElementById("kpi-squad-points").textContent = squad.weeklyPoints.toLocaleString();
  document.getElementById("kpi-user-points").textContent = user.points.toLocaleString();
  document.getElementById("kpi-user-name").textContent = user.name;
  document.getElementById("kpi-user-streak").textContent = `${user.streakDays} Days 🔥`;
  document.getElementById("kpi-badge-count").textContent = `${user.unlockedBadges.length} / ${BADGE_CATALOG.length}`;
}

function renderLeaderboards(activeSquad) {
  const cycle = state.leaderboardCycle;
  const ranked = [...state.squads].sort(
    (a, b) => getSquadPointsByCycle(b, cycle) - getSquadPointsByCycle(a, cycle)
  );

  const tbody = document.getElementById("squad-leaderboard-body");
  tbody.innerHTML = ranked
    .map((sq, idx) => {
      const pts = getSquadPointsByCycle(sq, cycle);
      const count = state.users.filter((u) => u.squadId === sq.id).length;
      const goalPct = Math.min(100, Math.round((sq.weeklyPoints / sq.weeklyGoal) * 100));
      const isCurrent = sq.id === activeSquad.id;
      return `
        <tr class="${isCurrent ? "active-squad-row" : ""}">
          <td><strong>#${idx + 1}</strong></td>
          <td>${sq.name}</td>
          <td>${count}</td>
          <td>${goalPct}%</td>
          <td class="text-right"><strong>${pts.toLocaleString()}</strong></td>
        </tr>
      `;
    })
    .join("");

  const members = state.users
    .filter((u) => u.squadId === activeSquad.id)
    .sort((a, b) => getUserPointsByCycle(b, cycle) - getUserPointsByCycle(a, cycle));

  const memberList = document.getElementById("member-standings-list");
  memberList.innerHTML = members
    .map((m, i) => `
      <div class="member-row">
        <div>
          <strong>#${i + 1} ${m.name}</strong>
          <span class="pill pill-muted" style="margin-left:0.4rem;">${m.streakDays}d streak</span>
        </div>
        <strong>${getUserPointsByCycle(m, cycle).toLocaleString()} pts</strong>
      </div>
    `)
    .join("");
}

function renderChart(squad, user) {
  const ctx = document.getElementById("weeklyProgressChart").getContext("2d");
  const labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

  if (chartInstance) {
    chartInstance.destroy();
  }

  chartInstance = new Chart(ctx, {
    type: state.chartType,
    data: {
      labels,
      datasets: [
        {
          label: `${squad.name} (Squad)`,
          data: squad.dailyTrend,
          backgroundColor: "rgba(34, 197, 94, 0.55)",
          borderColor: "#22c55e",
          borderWidth: 2,
          tension: 0.35,
          fill: state.chartType === "line",
        },
        {
          label: `${user.name} (Personal)`,
          data: user.personalTrend,
          backgroundColor: "rgba(56, 189, 248, 0.55)",
          borderColor: "#38bdf8",
          borderWidth: 2,
          tension: 0.35,
          fill: false,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { labels: { color: "#cbd5e1" } },
      },
      scales: {
        x: { ticks: { color: "#94a3b8" }, grid: { color: "rgba(148, 163, 184, 0.1)" } },
        y: { ticks: { color: "#94a3b8" }, grid: { color: "rgba(148, 163, 184, 0.1)" }, beginAtZero: true },
      },
    },
  });
}

function renderBadges(user) {
  const grid = document.getElementById("badges-grid");
  document.getElementById("badge-progress-pill").textContent = `${user.unlockedBadges.length} Unlocked`;

  grid.innerHTML = BADGE_CATALOG.map((badge) => {
    const unlocked = user.unlockedBadges.includes(badge.id);
    return `
      <div class="badge-item ${unlocked ? "unlocked" : "locked"}">
        <span class="badge-icon">${badge.icon}</span>
        <div>
          <span class="badge-name">${badge.name} ${unlocked ? "✓" : "🔒"}</span>
          <span class="badge-desc">${badge.desc}</span>
        </div>
      </div>
    `;
  }).join("");
}

function renderFeed(squad) {
  const feedEl = document.getElementById("activity-feed");
  const items = state.feed.filter((f) => f.squadId === squad.id);

  if (items.length === 0) {
    feedEl.innerHTML = `<p class="card-sub">No squad activity yet. Log a workout to kick things off!</p>`;
    return;
  }

  feedEl.innerHTML = items
    .map((item) => `
      <div class="feed-item">
        <div>
          <div class="feed-text">${item.text}</div>
          <div class="feed-meta">${item.time}</div>
        </div>
        <button class="highfive-btn" data-feed-id="${item.id}">🙌 ${item.highFives}</button>
      </div>
    `)
    .join("");
}

function renderWorkoutsTable(squad) {
  const tbody = document.getElementById("workouts-table-body");
  const rows = state.workouts.filter((w) => w.squadId === squad.id);

  tbody.innerHTML = rows
    .map((w) => `
      <tr>
        <td><strong>${w.userName}</strong></td>
        <td>${w.exercise}</td>
        <td>${w.duration} min</td>
        <td>${w.distance > 0 ? `${w.distance.toFixed(1)} km` : "—"}</td>
        <td>${w.intensity}</td>
        <td class="text-right"><strong>+${w.points}</strong></td>
      </tr>
    `)
    .join("");
}

function updateMetPreview() {
  const exercise = document.getElementById("exercise-type").value;
  const intensity = document.getElementById("intensity-level").value;
  const duration = Number(document.getElementById("duration-mins").value) || 0;
  const met = MET_FACTORS[exercise] ?? 6.0;
  const mult = INTENSITY_MULTIPLIERS[intensity] ?? 1.0;
  const pts = calculateMetPoints(exercise, duration, intensity);

  document.getElementById("met-formula-readout").textContent = `${duration} mins × ${met} × ${mult} = ${pts} pts`;
  document.getElementById("met-preview-points").textContent = `${pts} pts`;
}

function recordWorkout({ exercise, intensity, duration, distance, note, sourceLabel = "" }) {
  const squad = getActiveSquad();
  const user = getActiveUser();
  const errorEl = document.getElementById("workout-form-error");

  if (duration <= 0 || duration > MAX_DAILY_MINUTES) {
    errorEl.textContent = `Duration must be between 1 and ${MAX_DAILY_MINUTES} minutes.`;
    errorEl.classList.remove("hidden");
    return false;
  }

  if (user.dailyMinutesLogged + duration > MAX_DAILY_MINUTES) {
    errorEl.textContent = `Daily sanity cap exceeded (${user.dailyMinutesLogged}/${MAX_DAILY_MINUTES} mins already logged today).`;
    errorEl.classList.remove("hidden");
    return false;
  }

  errorEl.classList.add("hidden");
  const points = calculateMetPoints(exercise, duration, intensity);

  // Incremental updates
  user.points += points;
  user.dailyPoints += points;
  user.monthlyPoints += points;
  user.workoutsCount += 1;
  user.dailyMinutesLogged += duration;
  user.maxSinglePoints = Math.max(user.maxSinglePoints, points);
  if (exercise === "Gym" || exercise === "Push-ups") {
    user.strengthCount += 1;
  }
  if (exercise === "Running" && distance > 0) {
    user.totalRunKm = Number((user.totalRunKm + distance).toFixed(1));
    user.maxRunKm = Math.max(user.maxRunKm, distance);
  }
  user.personalTrend[user.personalTrend.length - 1] += points;

  squad.weeklyPoints += points;
  squad.dailyPoints += points;
  squad.monthlyPoints += points;
  squad.dailyTrend[squad.dailyTrend.length - 1] += points;

  const workoutEntry = {
    id: `w-${Date.now()}`,
    squadId: squad.id,
    userId: user.id,
    userName: user.name,
    exercise: sourceLabel ? `${exercise} (${sourceLabel})` : exercise,
    duration,
    distance,
    intensity,
    points,
    note,
    timestamp: "Just now",
  };
  state.workouts.unshift(workoutEntry);

  const newBadges = evaluateBadges(user);
  const badgeText = newBadges.length > 0 ? ` Unlocked: ${newBadges.map((b) => b.name).join(", ")}!` : "";

  state.feed.unshift({
    id: `f-${Date.now()}`,
    squadId: squad.id,
    text: `${user.name} logged ${distance > 0 ? `${distance} km ` : ""}${exercise} (${duration}m, ${intensity}) for +${points} pts!${badgeText}`,
    time: "Just now",
    highFives: 1,
  });

  saveState();
  renderAll();
  showToast(`+${points} MET points added to ${squad.name}!${badgeText}`);
  return true;
}

// Event Listeners
document.addEventListener("DOMContentLoaded", () => {
  renderAll();

  document.getElementById("squad-switcher").addEventListener("change", (e) => {
    state.activeSquadId = e.target.value;
    saveState();
    renderAll();
  });

  document.getElementById("user-switcher").addEventListener("change", (e) => {
    state.activeUserId = e.target.value;
    saveState();
    renderAll();
  });

  document.querySelectorAll(".seg-btn[data-cycle]").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".seg-btn[data-cycle]").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      state.leaderboardCycle = btn.dataset.cycle;
      saveState();
      renderLeaderboards(getActiveSquad());
      renderHeroAndBoss(getActiveSquad(), getActiveUser());
    });
  });

  document.querySelectorAll(".seg-btn.chart-mode").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".seg-btn.chart-mode").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      state.chartType = btn.dataset.chart;
      saveState();
      renderChart(getActiveSquad(), getActiveUser());
    });
  });

  // Modal controls
  const logModal = document.getElementById("modal-log-workout");
  const squadModal = document.getElementById("modal-create-squad");

  document.getElementById("btn-open-log").addEventListener("click", () => {
    document.getElementById("workout-form-error").classList.add("hidden");
    updateMetPreview();
    logModal.classList.remove("hidden");
  });

  document.getElementById("btn-open-squad").addEventListener("click", () => {
    squadModal.classList.remove("hidden");
  });

  document.querySelectorAll(".close-modal").forEach((btn) => {
    btn.addEventListener("click", () => {
      logModal.classList.add("hidden");
      squadModal.classList.add("hidden");
    });
  });

  ["exercise-type", "intensity-level", "duration-mins"].forEach((id) => {
    document.getElementById(id).addEventListener("input", updateMetPreview);
    document.getElementById(id).addEventListener("change", updateMetPreview);
  });

  document.getElementById("workout-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const ok = recordWorkout({
      exercise: document.getElementById("exercise-type").value,
      intensity: document.getElementById("intensity-level").value,
      duration: Number(document.getElementById("duration-mins").value),
      distance: Number(document.getElementById("distance-km").value) || 0,
      note: document.getElementById("workout-note").value.trim(),
    });
    if (ok) {
      logModal.classList.add("hidden");
      e.target.reset();
      document.getElementById("duration-mins").value = 30;
      document.getElementById("distance-km").value = 5;
      updateMetPreview();
    }
  });

  document.getElementById("squad-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const name = document.getElementById("new-squad-name").value.trim();
    const motto = document.getElementById("new-squad-motto").value.trim();
    const size = Math.min(6, Math.max(4, Number(document.getElementById("new-squad-size").value) || 4));
    const weeklyGoal = Number(document.getElementById("new-squad-goal").value) || 2000;
    const code = `${name.replace(/[^A-Za-z]/g, "").slice(0, 4).toUpperCase() || "SQD"}-${Math.floor(100 + Math.random() * 900)}`;

    const newSquadId = `sq-${Date.now()}`;
    state.squads.push({
      id: newSquadId,
      name,
      inviteCode: code,
      motto,
      weeklyGoal,
      weeklyPoints: 0,
      dailyPoints: 0,
      monthlyPoints: 0,
      dailyTrend: [0, 0, 0, 0, 0, 0, 0],
    });

    for (let i = 1; i <= size; i++) {
      state.users.push({
        id: `u-${Date.now()}-${i}`,
        squadId: newSquadId,
        name: i === 1 ? `Captain ${name.split(" ")[0]}` : `Recruit #${i}`,
        points: 0,
        dailyPoints: 0,
        monthlyPoints: 0,
        streakDays: 1,
        workoutsCount: 0,
        strengthCount: 0,
        totalRunKm: 0,
        maxRunKm: 0,
        maxSinglePoints: 0,
        dailyMinutesLogged: 0,
        unlockedBadges: [],
        personalTrend: [0, 0, 0, 0, 0, 0, 0],
      });
    }

    state.activeSquadId = newSquadId;
    saveState();
    renderAll();
    squadModal.classList.add("hidden");
    e.target.reset();
    showToast(`Created "${name}" (${size} members, invite code: ${code})!`);
  });

  // High-five delegation
  document.getElementById("activity-feed").addEventListener("click", (e) => {
    const btn = e.target.closest(".highfive-btn");
    if (!btn) return;
    const item = state.feed.find((f) => f.id === btn.dataset.feedId);
    if (item) {
      item.highFives += 1;
      saveState();
      renderFeed(getActiveSquad());
    }
  });

  // Strava / Fit mock sync
  document.getElementById("btn-sync-strava").addEventListener("click", () => {
    recordWorkout({
      exercise: "Running",
      intensity: "High",
      duration: 25,
      distance: 5.2,
      note: "Synced from wearable GPX export",
      sourceLabel: "Strava Sync",
    });
  });

  // Squad nudge reminder
  document.getElementById("btn-nudge-squad").addEventListener("click", () => {
    const squad = getActiveSquad();
    const remaining = Math.max(0, squad.weeklyGoal - squad.weeklyPoints);
    showToast(`Reminder sent to ${squad.name}: ${remaining.toLocaleString()} pts left to hit the weekly goal!`);
    if ("Notification" in window && Notification.permission === "granted") {
      new Notification("FitForge Squad Nudge", {
        body: `${squad.name} needs ${remaining.toLocaleString()} pts to reach the weekly target!`,
      });
    } else if ("Notification" in window && Notification.permission !== "denied") {
      Notification.requestPermission();
    }
  });

  // Reset demo
  document.getElementById("btn-reset-demo").addEventListener("click", () => {
    localStorage.removeItem(STORAGE_KEY);
    state = createInitialState();
    renderAll();
    showToast("Demo data reset to initial state.");
  });
});
